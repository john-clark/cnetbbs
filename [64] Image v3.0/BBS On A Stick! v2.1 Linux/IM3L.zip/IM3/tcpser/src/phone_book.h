
#define PH_BOOK_SIZE    100
#define PH_ENTRY_SIZE   128

int pb_init(void);
int pb_add(char *from, char *to);
int pb_search(char *number, char* address);
