#./bbs batch
cd ~/IM3/DiskImages
x64sc -config ~/IM3/Config/config.ini -cartcrt ~/IM3/Bins/ltk.crt -ltkimage0 ~/IM3/DiskImages/ltkernal30-disk0.dlk -ltkimage1 ~/IM3/DiskImages/ltkernal30-disk1.dlk -ltkimage2 ~/IM3/DiskImages/ltkernal30-disk2.dlk
