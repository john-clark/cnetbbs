#!/bin/bash
# v=2309051800
# this bash script was written by al derosa (bucko) for the bbs on a stick project
# released by the wrong number family of bbs' please do not remove these hastag
# statements for more info on the bbs on a stick project go to www.wrgnbr.com
# thank you - al derosa
#
#update and upgrade
sudo apt -y update
sudo apt -y upgrade 
#install network & pre-requisites
sudo apt-get -y install cifs-utils gvfs-backends make gcc build-essential subversion autoconf
sudo apt-get -y install automake byacc flex xa65 texinfo texlive-fonts-recommended dos2unix libpulse-dev
sudo apt-get -y install libasound2-dev libglew-dev libpulse-dev texi2html
sudo apt-get -y install libreadline-dev libgif-dev libjpeg-dev libpcap-dev libpng-dev
sudo apt-get -y install libsdl2-dev libsdl2-image-dev
#build tcpser
cd
cd IM3/tcpser
sudo make clean
sudo make
sudo cp tcpser /usr/local/bin/tcpser_1.1.5
cd
#build and make vice
mkdir myworkdir
cd myworkdir
svn checkout https://svn.code.sf.net/p/vice-emu/code/trunk vice-trunk
#svn checkout -r40835 https://svn.code.sf.net/p/vice-emu/code/trunk vice-trunk
#cp -r ~/IM3/nissanetvice/aciacore.c ~/myworkdir/vice-trunk/vice/src
#cp -r ~/IM3/nissanetvice/rs232net.c ~/myworkdir/vice-trunk/vice/src/rs232drv
cd vice-trunk/vice
./autogen.sh
./configure --enable-sdlui2 --with-sdlsound --without-png
make
sudo make install
cd
#chomod script files
cd IM3
chmod +x im3.sh
chmod +x im3tcpser.sh
chmod +x im3vice.sh
sudo reboot now
exit 0


