#!/bin/bash
xfce4-terminal -x ~/IM3/./im3tcpser.sh &
xfce4-terminal -x ~/IM3/./im3vice.sh &
exit 0
