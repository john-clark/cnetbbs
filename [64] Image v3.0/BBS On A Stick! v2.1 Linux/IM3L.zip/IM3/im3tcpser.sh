#!/bin/bash
tcpser_1.1.5 -s38400 -v 25238 -p 6400 -l 4
